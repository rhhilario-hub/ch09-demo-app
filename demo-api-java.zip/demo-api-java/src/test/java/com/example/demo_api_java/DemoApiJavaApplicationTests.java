package com.example.demo_api_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApiJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
