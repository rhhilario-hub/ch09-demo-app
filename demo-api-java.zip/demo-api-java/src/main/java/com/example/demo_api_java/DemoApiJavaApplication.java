package com.example.demo_api_java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApiJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApiJavaApplication.class, args);
	}

}
